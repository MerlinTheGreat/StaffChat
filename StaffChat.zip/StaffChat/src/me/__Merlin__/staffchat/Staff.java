package me.__Merlin__.staffchat;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class Staff extends JavaPlugin implements Listener
{
String prefix = "�e�lSTAFF �8> �7";
private ArrayList<Player> staff = new ArrayList<Player>();

public void onEnable() {
	Bukkit.getServer().getPluginManager().registerEvents(this, this);
	Bukkit.getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
		@Override
		public void run() {
			for (Player p : Bukkit.getOnlinePlayers()) {
				if (staff.contains(p)) {
					return;
				}
			}
		}
	}, 0, 60);
}
   @EventHandler
   public void onChat(AsyncPlayerChatEvent e) {
	   Player p = e.getPlayer();
	   
	   if(staff.contains(p)) {
		   e.setCancelled(true);
		   for(Player un : staff) {
			   un.sendMessage(prefix + p.getName() + " �8> �c�l " + e.getMessage());
		   }
		   return;
	   }
   }
	   @Override
	   public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		   if(!(sender instanceof Player)) {
			   sender.sendMessage("�4You must be a living tissue to use this!");
			   return false;
		   }
		   Player p = (Player) sender;
		   if(label.equalsIgnoreCase("sc")) {
			   if(!(p.hasPermission("sc.staff"))) {
				   p.sendMessage(ChatColor.translateAlternateColorCodes('&', "&e&lSTAFF &8> &7YOU must be a &f&lTRAINEE &7to use this!"));
				   return false;
			   }
			   if(!(staff.contains(p))) {
				   p.sendMessage(prefix + ChatColor.GREEN + "You have entered the Sneaky Staff Chat :C!");
				   staff.add(p);
			   }
			   else if (staff.contains(p)) {
				   p.sendMessage(prefix + ChatColor.RED + "You have left the Sneaky Staff chat :c");
				   staff.remove(p);
			   }
		   }
		   return false;
	   }
   }
